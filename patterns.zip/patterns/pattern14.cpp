#include <iostream>

using namespace std;

int main()
{
	int n;
	cout<<"Enter a positive number: ";
	cin>>n;

	for (int i=1; i<=n; i++)
	{
		for (int s=1; s<=n-i; s++)
		{
			cout<<" ";
		}
    	for (int p=1; p<=(i*2)-1; p++)
    	{
    		cout<<"*";
    	}
		cout<<endl;
	}

	for ( int i=n-1; i>=1; i--)
	{
		for (int s=1; s<=(n-i); s++)
		{
			cout<<" ";
		}
		for (int p=1; p<=(i*2)-1; p++)
		{
			cout<<"*";
		}
		cout<<endl;
	}
}


/* pattern
   *
  ***
 *****
  ***
   *
*/