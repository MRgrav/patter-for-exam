#include <iostream>

using namespace std;

int main()
{
	int n;
	cout<<"Enter a postive number : ";
	cin>>n;

	for (int i=1; i<=n; i++)
	{
		if (i==1 || i==n)
		{
			for(int p=1; p<=n; p++)
			{
				cout<<"* ";
			}
		}
		else
		{
			cout<<"* ";
			for(int s=1; s<=n-2; s++)
			{
				cout<<"  ";
			}
			cout<<"* ";
		}
		cout<<endl;
	}
}

/* 




*****
*   *
*   *
*   *
*****
*/
