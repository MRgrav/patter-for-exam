#include<iostream>

using namespace std;

int main()
{
	int n;
	cout<<"Enter a positive integer number : ";
	cin>>n;				//n is the number of rows of the * pattern
	for(int i=1; i<=n; i++)			//for rows
	{
		for(int j=n; j>=0; j--)		//for columns
		{
			if(j>=(n-i))
				cout<<" ";
			else
				cout<<i;
		}
		cout<<endl;
	}	
	return 0;
}