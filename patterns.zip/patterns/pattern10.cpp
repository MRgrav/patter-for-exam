#include <iostream>

using namespace std;

int main()
{
	int n, j;
	cout<<"Enter a positive integer number : ";
	cin>>n;
	for (int i=1; i<(2*n); i++)
	{
		if (i>n)
		{
			for (j=1; j<=(n-(i%n)); j++)
			{
				cout<<"@";
			}
		}
		else
		{
			for (j=1; j<=i; j++)
			{
				cout<<"@";
			}
		}
		cout<<endl;
	}
	return 0;
}