#include<iostream>

using namespace std;

int main()
{
	int n;
	cout<<"Number please : ";
	cin>>n;

	for (int i=1, a=1; i<=n; i++)
	{
		for (int s=1; s<=(n-i); s++)
		{
			cout<<" ";
		}
		for (int k=1; k<=i; k++)
		{
			cout<<a<<" ";
		}
		a++;
		cout<<endl;
	}
	return 0;
}