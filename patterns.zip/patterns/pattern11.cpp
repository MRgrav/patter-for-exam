#include <iostream>

using namespace std;

int main()
{
	int n, b, s;
	cout<<"Enter a positive integer number : ";
	cin>>n;
	b = (n+1)/2;
	for (int i=1; i<=n; i++)
	{
		//space condition
		if (i<=b)
		{
			for (s=1; s<=(b-i); s++)
			{
				cout<<"  ";
			}
		}
		else
		{
			for (s=1; s<=(i%b); s++)
			{
				cout<<"  ";
			}

		}
		//spot condition
		if (i<=b)
		{
			for (s=1; s<=(2*i)-1; s++)
			{
				cout<<"@ ";
			}
		}
		else
		{
			for (s=1; s<=n-(2*(i%b)); s++)
			{
				cout<<"@ ";
			}
		}
		cout<<endl;
	}
	return 0;
}