#include<iostream>

using namespace std;

int main()
{
	int n, k=0;
	cout<<"Number please : ";
	cin>>n;

	for (int i=1; i<=n; i++)
	{
		for (int s=1; s<=(n-i); s++)
		{
			cout<<" ";
		}
		while (k!=(2*i)-1)
		{
			cout<<"@";
			k++;
		}
		cout<<endl;
		k=0;
	}
	return 0;
}