//FASTPOW USING RECURSION
#include <iostream>

using namespace std;
int step=0;
int main()
{
	int pow(int, int);
	int a=2,b=10;
	cout<<"power of "<<a<<" "<<b<<" : "<<pow(a,b);
	cout<<"\nsteps : "<<step;
	return 0;
}
int pow(int n, int m)
{
	step++;
	if (m==0)
	{
		return 1;
	}
	if (m%2==0)
	{
		return pow(n*n,m/2); 
	}
	return n * pow(n,m-1);
}